define(function() {
	"use strict";

	function Request() {

	}

	Request.prototype.addParam = function() {

	};

	return Request;
});