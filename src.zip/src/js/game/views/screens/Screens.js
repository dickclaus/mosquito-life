define(function() {
	"use strict";

	var Screens = {};
	Screens.GAME_SCREEN = "GAME_SCREEN";
	Screens.PLAY_SCREEN = "PLAY_SCREEN";

	return Screens;
});
